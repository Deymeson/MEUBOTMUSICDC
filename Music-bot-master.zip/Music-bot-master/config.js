module.exports = {
    app: {
        token: 'MTA2NzI2NDA1MjEyMTg0MTc0NQ.GeHy9e.sS3EgRns_O3AQO5CVwUVhgRHYK_UP3OW2Cqrm0',
        playing: '< [MCPE] - POKECITY >',
        global: true,
        guild: 'XXX'
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: '',
            commands: []
        },
        maxVol: 100,
        leaveOnEnd: true,
        loopMessage: false,
        spotifyBridge: true,
        defaultvolume: 75,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
